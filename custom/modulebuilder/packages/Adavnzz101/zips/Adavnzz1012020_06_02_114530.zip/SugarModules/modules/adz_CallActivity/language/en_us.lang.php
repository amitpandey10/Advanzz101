<?php 
 // created: 2020-06-02 11:45:30
$mod_strings['LBL_ASSIGNED_TO_ID'] = 'Assigned User Id';
$mod_strings['LBL_ASSIGNED_TO_NAME'] = 'Assigned to';
$mod_strings['LBL_SECURITYGROUPS'] = 'Security Groups';
$mod_strings['LBL_SECURITYGROUPS_SUBPANEL_TITLE'] = 'Security Groups';
$mod_strings['LBL_ID'] = 'ID';
$mod_strings['LBL_DATE_ENTERED'] = 'Date Created';
$mod_strings['LBL_DATE_MODIFIED'] = 'Date Modified';
$mod_strings['LBL_MODIFIED'] = 'Modified By';
$mod_strings['LBL_MODIFIED_NAME'] = 'Modified By Name';
$mod_strings['LBL_CREATED'] = 'Created By';
$mod_strings['LBL_DESCRIPTION'] = 'Description';
$mod_strings['LBL_DELETED'] = 'Deleted';
$mod_strings['LBL_NAME'] = 'Name';
$mod_strings['LBL_CREATED_USER'] = 'Created by User';
$mod_strings['LBL_MODIFIED_USER'] = 'Modified by User';
$mod_strings['LBL_LIST_NAME'] = 'Name';
$mod_strings['LBL_EDIT_BUTTON'] = 'Edit';
$mod_strings['LBL_REMOVE'] = 'Remove';
$mod_strings['LBL_ASCENDING'] = 'Ascending';
$mod_strings['LBL_DESCENDING'] = 'Descending';
$mod_strings['LBL_OPT_IN'] = 'Opt In';
$mod_strings['LBL_OPT_IN_PENDING_EMAIL_NOT_SENT'] = 'Pending Confirm opt in, Confirm opt in not sent';
$mod_strings['LBL_OPT_IN_PENDING_EMAIL_SENT'] = 'Pending Confirm opt in, Confirm opt in sent';
$mod_strings['LBL_OPT_IN_CONFIRMED'] = 'Opted in';
$mod_strings['LBL_LIST_FORM_TITLE'] = 'CallActivity List';
$mod_strings['LBL_MODULE_NAME'] = 'CallActivity';
$mod_strings['LBL_MODULE_TITLE'] = 'CallActivity';
$mod_strings['LBL_HOMEPAGE_TITLE'] = 'My CallActivity';
$mod_strings['LNK_NEW_RECORD'] = 'Create CallActivity';
$mod_strings['LNK_LIST'] = 'View CallActivity';
$mod_strings['LNK_IMPORT_ADZ_CALLACTIVITY'] = 'Import CallActivity';
$mod_strings['LBL_SEARCH_FORM_TITLE'] = 'Search CallActivity';
$mod_strings['LBL_HISTORY_SUBPANEL_TITLE'] = 'View History';
$mod_strings['LBL_ACTIVITIES_SUBPANEL_TITLE'] = 'Activities';
$mod_strings['LBL_ADZ_CALLACTIVITY_SUBPANEL_TITLE'] = 'CallActivity';
$mod_strings['LBL_NEW_FORM_TITLE'] = 'New CallActivity';

?>
